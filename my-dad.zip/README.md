## Создание проекта
```shell
python -m venv .venv
.venv/Scripts/activate
pip install --index-url http://packages.webflare.ru/simple --trusted-host packages.webflare.ru "fastapi[standard]" alembic bcrypt pyjwt sqlalchemy aiosqlite
alembic init -t async migrations
```
## Структура проекта
```text
├───.venv/
├───migrations/
└───app/
    ├───api/
    │   ├───__init__.py
    │   ├───department.py
    │   ├───clinic.py
    │   ├───user.py
    │   └───base.py
    ├───core/
    │   ├───database.py
    │   ├───config.py
    │   ├───utils.py
    │   └───auth.py
    ├───models/
    │   ├───__init__.py
    │   ├───department.py
    │   ├───clinic.py
    │   ├───user.py
    │   └───base.py
    ├───schemas/
    │   ├───__init__.py
    │   ├───department.py
    │   ├───clinic.py
    │   └───user.py
    ├───services/
    │   ├───__init__.py
    │   ├───department.py
    │   ├───clinic.py
    │   └───user.py
    ├───repositories/
    │   ├───__init__.py
    │   ├───department.py
    │   ├───clinic.py
    │   ├───user.py
    │   └───base.py
    └───main.py
```


### 1. Конфигурация и база данных
Создать файлы `app/core/config.py` и `app/core/settings.py`
#### config.py
```python
from pydantic_settings import BaseSettings


class Settings(BaseSettings):
    DATABASE_URL: str = "sqlite+aiosqlite:///db.sqlite3"
    # Другие настройки


settings = Settings()
```
#### settings.py
```python
from sqlalchemy.ext.asyncio import create_async_engine, async_sessionmaker, AsyncSession
from config import settings

engine = create_async_engine(
    settings.DATABASE_URL,
    echo=True,
)

factory = async_sessionmaker(
    engine,
    class_=AsyncSession,
    autoflush=False,
    expire_on_commit=False,
)


async def get_session() -> AsyncSession:
    async with factory() as session:
        try:
            yield session
        except Exception:
            await session.rollback()
            raise
        finally:
            await session.close()
```
### 2. Модели и миграции
Создать модели `Base`, `Clinic`, `Department`, `User` и экспортировать через `app/models/__init__.py`
#### base.py
```python
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column, relationship
from sqlalchemy import Integer, String, ForeignKey


class Base(DeclarativeBase):
    __abstract__ = True

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True, index=True)


__all__ = [
    "Base", "Mapped", "mapped_column", "relationship",
    "Integer", "String", "ForeignKey",
]
```
#### \_\_init\_\_.py
```python
from .base import Base
from .clinic import Clinic
from .department import Department
from .user import User

__all__ = [
    "Base", 
    "Clinic",
    "Department",
    "User",
]
```
Изменить `env.py`
#### env.py
```python
from app.models import Base, Clinic, Department, User
from app.core.config import settings
```
```python
# add your model's MetaData object here
# for 'autogenerate' support
# from myapp import mymodel
# target_metadata = mymodel.Base.metadata
target_metadata = Base.metadata
```
```python
# other values from the config, defined by the needs of env.py,
# can be acquired:
# my_important_option = config.get_main_option("my_important_option")
# ... etc.
config.set_main_option("sqlalchemy.url", settings.DATABASE_URL)
```
Применить миграции
```shell
alembic revision --autogenerate -m "Initial revision"
alembic upgrade head
```
### 3. Репозитории (CRUD)
#### base.py
```python
from app.models import Base
from app.core.database import AsyncSession
from sqlalchemy import select
from typing import TypeVar, Generic, Type


T = TypeVar("T", bound=Base)


class BaseRepository(Generic[T]):
    def __init__(self, model: Type[T], session: AsyncSession):
        self.model = model
        self.session = session

    async def list(self, offset: int = 0, limit: int = 10):
        q = select(self.model).offset(offset).limit(limit)
        res = await self.session.execute(q)
        return res.scalars().all()

    async def create(self, **kwargs):
        _obj = self.model(**kwargs)
        self.session.add(_obj)
        await self.session.commit()
        await self.session.refresh(_obj)
        return _obj

    async def retrieve(self, id: int):
        q = select(self.model).where(self.model.id == id)
        res = await self.session.execute(q)
        return res.scalar_one_or_none()

    async def update(self, id: int, **kwargs):
        _obj = await self.retrieve(id) # TODO: нормально сделать короче
        for name, value in kwargs:
            setattr(_obj, name, value)
        await self.session.commit()
        await self.session.refresh(_obj)
        return _obj

    async def delete(self, id: int):
        _obj = await self.retrieve(id)
        await self.session.delete(_obj)
        await self.session.commit()
```

### 4. Аутентификация
#### auth.py
```python
import bcrypt, jwt
from datetime import datetime, timedelta
from fastapi import Depends, HTTPException, status
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from app.core.config import settings
from app.repositories import UserRepository, get_user_repository


security = HTTPBearer()


def hash_password(password: str):
    password_bytes = password.encode()[:72]
    password_hashed = bcrypt.hashpw(password_bytes, bcrypt.gensalt())
    return password_hashed.decode()


def verify_password(password: str, password_hashed: str):
    return bcrypt.checkpw(
        password=password.encode()[:72],
        hashed_password=password_hashed.encode()[:72],
    )


def encode_token(id: int):
    now = datetime.now()
    exp = now + timedelta(hours=2)
    payload = {
        "iat": int(now.timestamp()),
        "exp": int(exp.timestamp()),
        "sub": id,
    }
    return jwt.encode(
        payload=payload,
        key=settings.SECRET_KEY,
        algorithm=settings.ALGORITHM,
    )


def decode_token(token: str):
    return jwt.decode(
        jwt=token,
        key=settings.SECRET_KEY,
        algorithms=[settings.ALGORITHM],
    )


async def get_current_user(
        credentials: HTTPAuthorizationCredentials = Depends(security),
        user_repo: UserRepository = Depends(get_user_repository),
):
    token = credentials.credentials
    payload = decode_token(token)
    if not payload or "sub" not in payload.keys():
        raise HTTPException(
            detail="Invalid token",
            status_code=status.HTTP_401_UNAUTHORIZED,
        )
    user_id = payload["sub"]
    user = await user_repo.retrieve(user_id)
    if not user:
        raise HTTPException(
            detail="Not found",
            status_code=status.HTTP_404_NOT_FOUND,
        )
    return user
```
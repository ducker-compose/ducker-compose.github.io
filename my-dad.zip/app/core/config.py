from pydantic_settings import BaseSettings


class Settings(BaseSettings):
    DATABASE_URL: str = "sqlite+aiosqlite:///db.sqlite3"
    SECRET_KEY: str = "b2fd3882-812f-4def-ad79-c3b7cbbe76cf"
    ALGORITHM: str = "HS256"


settings = Settings()

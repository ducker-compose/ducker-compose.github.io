import bcrypt, jwt
from datetime import datetime, timedelta
from fastapi import Depends, HTTPException, status
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from app.core.config import settings
from app.repositories import UserRepository, get_user_repository


security = HTTPBearer()


def hash_password(password: str):
    password_bytes = password.encode()[:72]
    password_hashed = bcrypt.hashpw(password_bytes, bcrypt.gensalt())
    return password_hashed.decode()


def verify_password(password: str, password_hashed: str):
    return bcrypt.checkpw(
        password=password.encode()[:72],
        hashed_password=password_hashed.encode()[:72],
    )


def encode_token(id: int): # payload -> token
    now = datetime.now()
    exp = now + timedelta(hours=2)
    payload = {
        "iat": int(now.timestamp()),
        "exp": int(exp.timestamp()),
        "sub": id,
    }
    return jwt.encode(
        payload=payload,
        key=settings.SECRET_KEY,
        algorithm=settings.ALGORITHM,
    )


def decode_token(token: str): # token -> payload
    return jwt.decode(
        jwt=token,
        key=settings.SECRET_KEY,
        algorithms=[settings.ALGORITHM],
    )


async def get_current_user(
        credentials: HTTPAuthorizationCredentials = Depends(security),
        user_repo: UserRepository = Depends(get_user_repository),
):
    token = credentials.credentials
    payload = decode_token(token)
    if not payload or "sub" not in payload.keys():
        raise HTTPException(
            detail="Invalid token",
            status_code=status.HTTP_401_UNAUTHORIZED,
        )
    user_id = payload["sub"]
    user = await user_repo.retrieve(user_id)
    if not user:
        raise HTTPException(
            detail="Not found",
            status_code=status.HTTP_404_NOT_FOUND,
        )
    return user

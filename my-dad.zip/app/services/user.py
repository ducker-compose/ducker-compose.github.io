from app.repositories import UserRepository, get_user_repository
from app.schemas import CreateUser, AuthorizationUser, ResponseUser
from app.core.auth import encode_token
from fastapi import Depends


class UserService:
    def __init__(self, repo: UserRepository):
        self.repo = repo

    async def register(self, data: CreateUser):
        username_exists = await self.repo.retrieve_by_username(data.username)
        if username_exists:
            raise ValueError(
                "User with this username already exists",
            )
        email_exists = await self.repo.retrieve_by_email(data.email)
        if email_exists:
            raise ValueError(
                "User with this email already exists",
            )
        _obj = await self.repo.create(**data.model_dump())
        token = encode_token(_obj.id)

        return ResponseUser(
            id=_obj.id,
            username=_obj.username,
            email=_obj.email,
            access_token=token,
        )

    async def login(self, data: AuthorizationUser):
        username_exists = await self.repo.retrieve_by_username(data.username)
        if not username_exists:
            raise ValueError(
                "Invalid credentials",
            )
        _obj = await self.repo.create(**data.model_dump())
        token = encode_token(_obj.id)

        return ResponseUser(
            id=_obj.id,
            username=_obj.username,
            email=_obj.email,
            access_token=token,
        )


def get_user_service(repo: UserRepository = Depends(get_user_repository)):
    return UserService(repo)

from .base import BaseModel, Optional


class CreateClinic(BaseModel):
    name: str
    description: str


class UpdateClinic(BaseModel):
    name: Optional[str] = None
    description: Optional[str] = None


class ResponseClinic(BaseModel):
    id: int
    name: str
    description: str
    user_id: int

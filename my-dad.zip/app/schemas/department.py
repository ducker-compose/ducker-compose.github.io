from .base import BaseModel


class CreateDepartment(BaseModel):
    name: str
    description: str
    balance: int
    clinic_id: int


class UpdateDepartment(BaseModel):
    name: Optional[str] = None
    description: Optional[str] = None
    balance: Optional[int] = None
    clinic_id: Optional[int] = None


class ResponseDepartment(BaseModel):
    id: int
    name: str
    description: str
    balance: int
    user_id: int
    clinic_id: int

from .base import BaseModel, EmailStr


class CreateUser(BaseModel):
    username: str
    email: EmailStr
    password: str


class AuthorizationUser(BaseModel):
    username: str
    email: EmailStr


class ResponseUser(BaseModel):
    id: int
    username: str
    email: str
    password: str
    token: str

from .base import Base, Mapped, mapped_column, String, ForeignKey, relationship
from .user import User


class Clinic(Base):
    __tablename__ = "clinics"

    name: Mapped[str] = mapped_column(String, nullable=False)
    description: Mapped[str] = mapped_column(String, nullable=False)
    user_id: Mapped[int] = mapped_column(ForeignKey(User.id, ondelete="CASCADE"))

    user = relationship("User", back_populates="clinic")
    department = relationship("Department", back_populates="clinic")

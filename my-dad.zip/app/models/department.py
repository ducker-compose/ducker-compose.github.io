from .base import Base, Mapped, mapped_column, String, Integer, ForeignKey, relationship
from .user import User
from .clinic import Clinic


class Department(Base):
    __tablename__ = "departments"

    name: Mapped[str] = mapped_column(String, nullable=False)
    description: Mapped[str] = mapped_column(String, nullable=False)
    balance: Mapped[int] = mapped_column(Integer, nullable=True)
    user_id: Mapped[int] = mapped_column(ForeignKey(User.id, ondelete="SET NULL"))
    clinic_id: Mapped[int] = mapped_column(ForeignKey(Clinic.id, ondelete="SET NULL"))

    user = relationship("User", back_populates="department")
    clinic = relationship("Department", back_populates="department")

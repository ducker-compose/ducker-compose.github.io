from .base import Base, Mapped, mapped_column, String, relationship


class User(Base):
    __tablename__ = "users"

    username: Mapped[str] = mapped_column(String, nullable=False)
    email: Mapped[str] = mapped_column(String, nullable=False)
    password: Mapped[str] = mapped_column(String, nullable=False)

    clinic = relationship("Clinic", back_populates="user")
    department = relationship("Department", back_populates="user")

from .base import BaseRepository, AsyncSession
from app.core.database import get_session
from app.models import Department
from fastapi import Depends


class DepartmentRepository(BaseRepository[Department]):
    def __init__(self, session: AsyncSession):
        super().__init__(model=Department, session=session)

    async def create(self, **kwargs):
        user_id = kwargs.get("user_id")
        if not user_id:
            raise ValueError("Undefined user_id")
        clinic_id = kwargs.get("clinic_id")
        if not clinic_id:
            raise ValueError("Undefined clinic_id")
        _obj = self.model(**kwargs)
        self.session.add(_obj)
        await self.session.commit()
        await self.session.refresh(_obj)
        return _obj


def get_department_repository(session: AsyncSession = Depends(get_session)):
    return DepartmentRepository(session)

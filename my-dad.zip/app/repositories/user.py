from .base import BaseRepository, AsyncSession, select
from app.core.database import get_session
from app.core.auth import hash_password
from app.models import User
from fastapi import Depends


class UserRepository(BaseRepository[User]):
    def __init__(self, session: AsyncSession):
        super().__init__(model=User, session=session)

    async def retrieve_by_username(self, username: str):
        q = select(self.model).where(self.model.username == username)
        res = await self.session.execute(q)
        return res.scalar_one_or_none()

    async def retrieve_by_email(self, email: str):
        q = select(self.model).where(self.model.email == email)
        res = await self.session.execute(q)
        return res.scalar_one_or_none()

    async def create(self, **kwargs):
        _obj = self.model(**kwargs)
        password_hashed = hash_password(_obj.password)
        _obj.password = password_hashed
        self.session.add(_obj)
        await self.session.commit()
        await self.session.refresh(_obj)
        return _obj


def get_user_repository(session: AsyncSession = Depends(get_session)):
    return UserRepository(session)

from app.models import Base
from app.core.database import AsyncSession
from sqlalchemy import select
from typing import TypeVar, Generic, Type


T = TypeVar("T", bound=Base)


class BaseRepository(Generic[T]):
    def __init__(self, model: Type[T], session: AsyncSession):
        self.model = model
        self.session = session

    async def list(self, offset: int = 0, limit: int = 10):
        q = select(self.model).offset(offset).limit(limit)
        res = await self.session.execute(q)
        return res.scalars().all()

    async def create(self, **kwargs):
        _obj = self.model(**kwargs)
        self.session.add(_obj)
        await self.session.commit()
        await self.session.refresh(_obj)
        return _obj

    async def retrieve(self, id: int):
        q = select(self.model).where(self.model.id == id)
        res = await self.session.execute(q)
        return res.scalar_one_or_none()

    async def update(self, id: int, **kwargs):
        _obj = await self.retrieve(id) # TODO: нормально сделать короче
        for name, value in kwargs:
            setattr(_obj, name, value)
        await self.session.commit()
        await self.session.refresh(_obj)
        return _obj

    async def delete(self, id: int):
        _obj = await self.retrieve(id)
        await self.session.delete(_obj)
        await self.session.commit()

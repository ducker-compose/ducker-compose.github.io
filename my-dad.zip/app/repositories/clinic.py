from .base import BaseRepository, AsyncSession
from app.core.database import get_session
from app.models import Clinic
from fastapi import Depends


class ClinicRepository(BaseRepository[Clinic]):
    def __init__(self, session: AsyncSession):
        super().__init__(model=Clinic, session=session)

    async def create(self, **kwargs):
        user_id = kwargs.get("user_id")
        if not user_id:
            raise ValueError("Undefined user_id")
        _obj = self.model(**kwargs)
        self.session.add(_obj)
        await self.session.commit()
        await self.session.refresh(_obj)
        return _obj


def get_clinic_repository(session: AsyncSession = Depends(get_session)):
    return ClinicRepository(session)

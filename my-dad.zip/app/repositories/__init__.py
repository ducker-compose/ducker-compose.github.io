from .base import BaseRepository
from .clinic import ClinicRepository, get_clinic_repository
from .department import DepartmentRepository, get_department_repository
from .user import UserRepository, get_user_repository

__all__ = [
    "BaseRepository",
    "ClinicRepository", "get_clinic_repository",
    "DepartmentRepository", "get_department_repository",
    "UserRepository", "get_user_repository",
]
